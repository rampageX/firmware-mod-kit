This is a collection of firmware packaging and obfuscation utilities.
