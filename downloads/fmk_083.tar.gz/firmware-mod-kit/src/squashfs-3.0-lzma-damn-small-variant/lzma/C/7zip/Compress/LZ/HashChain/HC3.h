// HC3.h

#ifndef __HC3_H
#define __HC3_H

#undef HC_NAMESPACE
#define HC_NAMESPACE NHC3

#define HASH_ARRAY_2

#include "HC.h"
#include "HCMain.h"

#undef HASH_ARRAY_2

#endif

