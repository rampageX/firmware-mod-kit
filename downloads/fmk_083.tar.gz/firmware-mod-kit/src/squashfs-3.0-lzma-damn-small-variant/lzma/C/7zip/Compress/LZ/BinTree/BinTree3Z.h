// BinTree3Z.h

#ifndef __BINTREE3Z_H
#define __BINTREE3Z_H

#undef BT_NAMESPACE
#define BT_NAMESPACE NBT3Z

#define HASH_ZIP

#include "BinTree.h"
#include "BinTreeMain.h"

#undef HASH_ZIP

#endif
