// Pat3H.h

#ifndef __PAT3H__H
#define __PAT3H__H

#undef PAT_CLSID
#define PAT_CLSID CLSID_CMatchFinderPat3H

#undef PAT_NAMESPACE
#define PAT_NAMESPACE NPat3H

#define __AUTO_REMOVE
#define __NODE_3_BITS
#define __HASH_3

#include "Pat.h"
#include "PatMain.h"

#undef __AUTO_REMOVE
#undef __NODE_3_BITS
#undef __HASH_3

#endif

